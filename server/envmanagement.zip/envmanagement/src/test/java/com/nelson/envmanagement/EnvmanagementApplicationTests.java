package com.nelson.envmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnvmanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
